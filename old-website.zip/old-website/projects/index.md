---
layout: mission
title: Sponsorship Opportunities
excerpt: "blair3sat's sponsorship tiers"
comments: false
---

<div style="font-size:36pt;color:#add8e6;display:inline;text-shadow:0px 2px 3px #6060e0;font-weight:bold;">Diamond</div><pre style="display:inline;">      </pre><div style="font-size:19pt;displaydisplay:inline;">  $30,000.00+</div>
* Part named after organization
* Large logo on letterhead
* Name lasered into chassis
* Personalized quarterly updates

---

<div style="font-size:36pt;color:Gold;display:inline;text-shadow:0px 2px 3px #CFB53B;font-weight:bold;">Gold</div><pre style="display:inline;">      </pre><div style="font-size:19pt;displaydisplay:inline;">  $10,000.00 – $30,000.00</div>
* Large logo on letterhead
* Name lasered into chassis
* Personalized quarterly updates

---

<div style="font-size:36pt;color:silver;display:inline;text-shadow:0px 2px 3px #999999;font-weight:bold;">Silver</div><pre style="display:inline;">      </pre><div style="font-size:19pt;displaydisplay:inline;">  $3,000.00 – $9,999.99</div>
* Medium logo on letterhead
* Personalized quarterly updates

---

<div style="font-size:36pt;color: #D2691E;display:inline;text-shadow:0px 2px 3px #8B4513;font-weight:bold;">Bronze</div><pre style="display:inline;">      </pre><div style="font-size:19pt;displaydisplay:inline;">  $300.00 – $2,999.99</div>
* Personalized quarterly updates

---

<div style="font-size:36pt;display:inline;text-shadow:0px 2px 3px #333333;font-weight:bold;">Support</div><pre style="display:inline;">      </pre><div style="font-size:19pt;displaydisplay:inline;">  $1.00 – $299.99</div>
* Annual updates

---
